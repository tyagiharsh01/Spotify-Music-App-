export type Song = {
    title?: string |null ;
    artist?: string |null;
}