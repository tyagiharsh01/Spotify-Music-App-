import { Component } from '@angular/core';
import { Song } from 'src/model/Song';
import { SpotifyService } from '../Services/spotify.service';
import { SpotifyRouterService } from '../Services/spotify-router.service';
import { FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-delete-playlist',
  templateUrl: './delete-playlist.component.html',
  styleUrls: ['./delete-playlist.component.css']
})
export class DeletePlaylistComponent {
  playListName?:string;
  song?:Song[]
  constructor(private spotify:SpotifyService,private router:SpotifyRouterService,private fb:FormBuilder){}
  deleteForm= this.fb.group({
    playListName: ['', Validators.required]
  })
  onSubmit(){
  const playListName = this.deleteForm.get('playListName')?.value;
 if (playListName) {
  this.playListName = playListName;
  this.spotify.getAllSongFromPlayList(this.playListName).subscribe({
    next: data => {
      this.song = data;
    },
    error: e => {
      alert("Failed to fetch Song");
      this.router.navigateToHome();
    }
  })
  }
}
}
