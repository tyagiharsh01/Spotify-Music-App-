import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Song } from 'src/model/Song';
import { SpotifyService } from '../Services/spotify.service';

@Component({
  selector: 'app-song',
  templateUrl: './song.component.html',
  styleUrls: ['./song.component.css']
})
export class SongComponent implements OnInit {
songData:Song[]=[]
@Output()
songAdded = new EventEmitter<Song>();
constructor(private spotifyService:SpotifyService){}
  ngOnInit(): void {
    this.spotifyService.getAllSong()
    .subscribe({
      next:data=>{
        this.songData=data;
      },
      error:e=>{
        alert("Failed to fetch Song");
      }
    })
  }
  songPlay(){
    alert("Song is Playing");
    
  }
  addSong(song:Song){
    alert("emit");
    this.songAdded.emit(song);
  }


}
