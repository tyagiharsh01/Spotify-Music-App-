import { Component } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
import { SpotifyRouterService } from '../Services/spotify-router.service';
import { AuthService } from '../Services/auth.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent {
  constructor(private route:Router,private spotify:SpotifyRouterService,private authService:AuthService){}
  submit(){
    this.route.navigateByUrl("/createPlayList");
  }
  showAllSong(){
    this.route.navigateByUrl("/showSong")
  }
  deleteSong(){
    this.route.navigateByUrl("/deletePlaylist")
  }
  logout() {
    alert('Do you want to logout?');
    localStorage.removeItem('jwt');
    localStorage.removeItem('email');
    this.authService.logout();
    this.spotify.navigateToHome();
  }

}
